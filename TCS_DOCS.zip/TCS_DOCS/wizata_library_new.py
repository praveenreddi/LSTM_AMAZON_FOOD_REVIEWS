import os
import sys
import glob
import pandas as pd
import numpy as np
import datetime
import re
import json
import joblib
import time
from scipy.optimize import curve_fit
from scipy.stats import linregress
import scipy.interpolate
from meteostat import Stations, Hourly
import plotly.graph_objects as go
import seaborn as sns
from matplotlib import pyplot as plt
from matplotlib import gridspec
from sklearn.preprocessing import StandardScaler
from tensorflow import keras
from keras.models import load_model
import subprocess
from rich.console import Console

pd.options.plotting.backend = "plotly"
run_env = os.environ.get('RUN_ENV')

# Uncomment to run local FER
# path_input = "/Users/ag/Documents/github/local_files_FER/input/"
# path_output = "/Users/ag/Documents/github/local_files_FER/output/"
# path_models = "/Users/ag/Documents/github/local_files_FER/models/"
# path_logs = "/Users/ag/Documents/github/local_files_FER/logs/"
# path_config = '/Users/ag/Documents/github/pot-mprop/be1/config/'

# Uncomment to run local KOR
# path_input = "/Users/ag/Documents/github/local_files_KO/input/"
# path_output = "/Users/ag/Documents/github/local_files_KO/output/"
# path_models = "/Users/ag/Documents/github/local_files_KO/models/"
# path_logs = "/Users/ag/Documents/github/local_files_KO/logs/"
# path_config = '/Users/ag/Documents/github/local_files_KO/config/'

# Uncomment to run local BE
# path_input = "/Users/ag/Documents/github/local_files_BE/input/"
# path_output = "/Users/ag/Documents/github/local_files_BE/output/"
# path_models = "/Users/ag/Documents/github/local_files_BE/models/"
# path_logs = "/Users/ag/Documents/github/local_files_BE/logs/"
# path_config = '/Users/ag/Documents/github/local_files_BE/config/'

# Uncomment to run local KUJ
# path_input = "/Users/ag/Documents/github/local_files_KUJ/input/"
# path_output = "/Users/ag/Documents/github/local_files_KUJ/output/"
# path_models = "/Users/ag/Documents/github/local_files_KUJ/models/"
# path_logs = "/Users/ag/Documents/github/local_files_KUJ/logs/"
# path_config = '/Users/ag/Documents/github/local_files_KUJ/config/'

# Uncomment to run local BE
#path_input = "/Users/Kashif/Downloads/DO/input/" 
#path_output = "/Users/Kashif/Downloads/DO/output/"
#path_models = "/Users/Kashif/Downloads/DO/models/"
#path_logs = "/Users/Kashif/Downloads/DO/logs/"
#path_config = '/Users/Kashif/Downloads/DO/config/'

# Uncomment to run local DO
# path_input = "/Users/ag/Documents/github/local_files_DO/input/"
# path_output = "/Users/ag/Documents/github/local_files_DO/output/"
# path_models = "/Users/ag/Documents/github/local_files_DO/models/"
# path_logs = "/Users/ag/Documents/github/local_files_DO/logs/"
# path_config = '/Users/ag/Documents/github/local_files_DO/config/'

# Uncomment to deploy
path_input = '/content/drive/MyDrive/RolPrs/DO-20220803T055058Z-001/DO-20220803T055058Z-001/DO/input' 
path_output = '/content/drive/MyDrive/RolPrs/DO-20220803T055058Z-001/DO-20220803T055058Z-001/DO/output_new'
path_models = '/content/drive/MyDrive/RolPrs/DO-20220803T055058Z-001/DO-20220803T055058Z-001/DO/models'
path_logs = '/content/drive/MyDrive/RolPrs/DO-20220803T055058Z-001/DO-20220803T055058Z-001/DO/logs'
path_config = '/content/drive/MyDrive/RolPrs/DO-20220803T055058Z-001/DO-20220803T055058Z-001/DO/config'

sys.path.append(path_config)  # path to configuration.py

# Uncomment to run local/training
#from loss_functions_library_phase_2 import *
#from configuration import configuration

# Uncomment to deploy
from loss_functions_library_phase_2 import *
from configuration import configuration


# Data Preparation
def get_raw_data(path, log):
    """
    Create DataFrame from multiple csv files in path. Used for batch/historical data.
    """
    all_files = glob.glob(
        os.path.join(path, "*.csv"))  # advisable to use os.path.join as this makes concatenation OS independent
    li = []
    for n, filename in enumerate(all_files):
        try:
            df = pd.read_csv(filename, sep=None, engine="python", encoding='utf-8-sig', index_col=0)
        except OSError as err:
            log.error("OS error: {0}".format(err))
        li.append(df)
    frame = pd.concat(li, axis=0, ignore_index=False)
    del (df)
    log.info('Raw DataFrame size: ' + str(frame.shape))
    return frame


def get_real_time_data(log, path, input_time_window='24h'):
    '''
    Create DataFrame from multiple csv files in path.
    Used for real time. Only opens the files included in the input_time_window.
    By default we open the last 10 days of data.
    '''
    all_files = np.array(glob.glob(
        os.path.join(path, "*.csv")))  # advisable to use os.path.join as this makes concatenation OS independent
    if len(all_files) == 0:
        log.error("Input CSV files not found")
    dates_ls = np.array([pd.to_datetime(f[-17:-4], format='%Y%m%d.%H%M') for f in all_files])
    # time_now = pd.to_datetime(time.localtime(), unit='s')
    # time_now = pd.to_datetime(datetime.datetime.now()).tz_localize(None)
    structTime = time.localtime()
    time_now = pd.to_datetime(datetime.datetime(*structTime[:6]))
    log.info('Time now: ' + str(time_now))
    # uncomment to open data on specific date
    # time_now = pd.to_datetime('2022-06-20 12:00:00') 

    time_init = time_now - pd.Timedelta(input_time_window)
    log.info('Time init: ' + str(time_init))

    sel_files = all_files[(dates_ls < time_now) & (dates_ls > time_init)]
    if len(sel_files) > 0:
        li = []
        for filename in sel_files:
            try:
                df = pd.read_csv(filename, sep=None, engine="python", encoding='utf-8-sig',
                                 index_col=0)  # working with any delimiter
            except OSError as err:
                log.error("OS error: {0}".format(err))
            li.append(df)

        frame = pd.concat(li, axis=0, ignore_index=False)
        del (df)
        del (li)
        frame = frame.sort_index()  # have a monotonic index
        # log.info("Input Data Retrieved")
        # log.info("Input data size: " + str(frame.shape))
    else:
        frame = []
        log.warning("No data available for " + str(time_now)[:10])
        exit()
    log.info('Raw DataFrame size:' + str(frame.shape))
    return frame


def remove_ML_in_sensor_name(sensor_name):
    """
    Sensor names in raw data extracted from TIS can have '__ML' or '_ML' at the end.
    This function removes it to match the sensor name in config_file.json
    """
    if sensor_name[-4:] == '__ML':
        return sensor_name[:-4]
    elif sensor_name[-3:] == '_ML':
        return sensor_name[:-3]
    else:
        return sensor_name


def remove_weird_symbols(word):
    """
    Replace weird symbols for _
    """
    return re.sub(r'[^A-Za-z0-9]', '_', word.replace('?', ''))


def extreme_value_capping(df, limits):
    try:
        for col in limits.keys():
            df[col] = df[col].clip(upper=limits[col][1], lower=limits[col][0])
        return df
    except KeyError as ke:
        pass
    finally:
        return df


def import_data(log):
    """
    This function imports:
    - config_file.json
    - stats_file.csv
    - raw input data as csv files
    """
    if not os.path.isfile(os.path.join(path_config, 'model_thresholds.json')):
        log.info('Config file not found. An empty model_thresholds.json was created in: ' + path_config)
        with open(os.path.join(path_config, 'model_thresholds.json'), 'w') as outfile:
            outfile.write(json.dumps({"train_means": {}, "train_stds": {}, "train_thresholds": {}}))
    with open(os.path.join(path_config, 'model_thresholds.json')) as f:
        config_file = json.load(f)
    log.info('model_thresholds.json loaded')

    if configuration['load_stats_file_from_BQ']:
        # use Kashif code to load stats file from BQ
        console = Console()
        DEVNULL = open(os.devnull, 'wb')
        with console.status('Updating configuration from BigQuery \n') as status:
            task = subprocess.run(['python', 'download_configuration.py'], stdout=DEVNULL, stderr=DEVNULL)
            if task.returncode != 0:
                log.info('Failed updating from BigQuery...Using old file')
                stats_file = pd.read_csv(os.path.join(path_config, 'stats_file.csv'), sep=None, engine="python",
                                         encoding='utf-8-sig', index_col='config_id')
            else:
                log.info('Updated configuration file successfully from BQ')
    else:
        log.info('Updated configuration file successfully from local')
        stats_file = pd.read_csv(os.path.join(path_config, 'stats_file.csv'), sep=None, engine="python",
                                 encoding='utf-8-sig', index_col='config_id')

    if stats_file['Description'].duplicated().sum() != 0:
        log.error('Duplicated Description in stats_file.csv. Please fix this and run all code again')
        log.error('List of Duplicated Description: ' + str(
            list(stats_file[stats_file['Description'].duplicated()]['Description'].unique())))
        raise SystemExit('Description duplicated in stats_file.csv. Please fix this and run all code again')
    stats_file['index'] = stats_file['index'].apply(remove_weird_symbols)
    stats_file['index'] = [remove_ML_in_sensor_name(sensor_name) for sensor_name in stats_file['index']]
    d = stats_file[['index', 'Description']].set_index('index').to_dict()['Description']
    log.info('stats_file.csv loaded')
    if configuration['real_time_data']:
        log.info('real_time_data set to TRUE. Opening last 24hs data...')
        df = get_real_time_data(log, path_input)  # run get_real_time_data
    else:
        log.info('real_time_data set to FALSE. Opening all files in the folder...')
        df = get_raw_data(path_input, log)
    df.columns = [remove_ML_in_sensor_name(sensor_name) for sensor_name in df.columns]
    df, df_std = data_preparation(df, d, stats_file, log)
    print(df.columns)  # function to process and condition data
    log.info('Import data OK')
    return df, d, config_file, stats_file, configuration, df_std


def data_preparation(df, d, stats_file, log):
    """
    Prepare DataFrame for training. This function replaces the old process_data()
    Input:
        - Original DataFrame (df)
        - Mapping Dictionary (d)
        - Stats File
    Returns:
        - filtered_df
        - df_std
    """
    df.columns = list(map(remove_weird_symbols, df.columns))  # apply remove_weird_symbols to column names
    if len(list(set(stats_file['index']) & set(df.columns))) == 0:
        raise SystemExit(
            'Sensor names in stats_file.csv and in Raw Data DO NOT match. Please fix this and run all code again.')
    else:
        df = df[list(set(stats_file['index']) & set(df.columns))]  # only keep the sensors present in the csv file
    df = df[df.index != 'Start Date']  # delete sensor names as values
    df.index = pd.to_datetime(df.index, utc=True, errors='coerce').tz_localize(None)  # convert index to datetime
    df.sort_index(inplace=True)  # sort data by date
    df = df.fillna(0)  # fill nulls with 0
    index_numbers_only = df.apply(lambda x: pd.to_numeric(x, errors='coerce')).dropna().astype(float).index
    df = df.loc[index_numbers_only]  # keep only rows with numeric values
    df = df.astype('float')  # convert data to numeric
    df = df[~df.index.duplicated(keep='first')]  # Drop duplicated index
    df_std = df.resample('1H').std().fillna(0)  # Resample to hour-wise data and save the std per hour
    df = df.resample('1H').mean()
    log.info('DataFrame size after resample/data cleaning:' + str(df.shape))
    df.rename(columns=d, inplace=True)  # Rename sensor names using Mapping Dictionary (d)
    return df, df_std


def get_surface_temperature(plant_coord_lat, plant_coord_long, **kwargs):
    """
    Get Meteo Data From Station nearby
    """
    if len(kwargs) > 0:
        roll_mean_window = kwargs["roll_mean_window"]
    else:
        roll_mean_window = "6h"
    stations = Stations()
    stations = stations.nearby(plant_coord_lat, plant_coord_long)
    station = stations.fetch(2)
    data = Hourly(station, start=datetime.datetime(2017, 1, 1), end=datetime.datetime.now())
    data = data.fetch()
    data = data.droplevel(level=0)  # one-level index
    data = data.sort_index()[["temp"]].rolling(roll_mean_window, closed="right").mean()
    return data


def filter_downtimes(df, sensor_name_to_filter_downtimes, log, restart_stoping_time="2h", min_power=600):
    """
    Use selected sensor and value from configuration.py to remove values when the machine is off
    """
    log.info('Filtering downtimes when ' + sensor_name_to_filter_downtimes + ' is under ' + str(min_power))
    try:
        df['running'] = np.where(df[sensor_name_to_filter_downtimes] > min_power, 1, 0)
        df["running_diff"] = df["running"].diff()
        df['operational'] = 1
        df["operational"][df["running"] == 0] = 0
        df['operational'].value_counts()

        start_dates = df[df["running_diff"] == -1]
        for sd in start_dates.index:
            try:
                init = sd - pd.Timedelta(restart_stoping_time)
                df['operational'].loc[init:sd] = 0
            except Exception:
                log.warning('Could not filter running_diff -1 from ' + str(init) + ' to ' + str(sd))

        end_dates = df[df["running_diff"] == 1]
        for ed in end_dates.index:
            try:
                fin = ed + pd.Timedelta(restart_stoping_time)
                df['operational'].loc[ed:fin] = 0
            except Exception:
                log.warning('Could not filter running_diff 1 from ' + str(init) + ' to ' + str(sd))
        df[['operational', 'running']].plot()
        log.info('Filter Downtimes OK')
    except Exception:
        log.warning("Sensor to filter downtimes not found.")
        df['operational'] = 0
    return df


def plot_corr(s1):
    """
    Correlation plot used in the Training Notebook.
    """
    s1_corr = s1.corr(method='pearson')
    plt.clf()
    cmap = sns.diverging_palette(220, 10, as_cmap=True)
    fig = plt.figure(figsize=(15, 10))
    gs = gridspec.GridSpec(1, 2)
    ax0 = plt.subplot(gs[0])
    sns.heatmap(s1_corr, cmap=cmap, vmax=1, center=0, square=True, linewidths=.5, cbar_kws={"shrink": .5}, annot=True,
                annot_kws={"size": 9})
    ax0.hlines([4, 8], *ax0.get_xlim())
    ax0.vlines([4, 8], *ax0.get_ylim())
    plt.tight_layout()
    display(plt.show())


def apply_temp_correction(df, stats_file, configuration, log):
    """
    Correct ambient temperature using information from meteostat library.
    """
    high_temp_max = configuration['high_temp_max']
    high_temp_mean = configuration['high_temp_mean']
    low_temp_max = configuration['low_temp_max']
    low_temp_mean = configuration['low_temp_mean']
    std_maping_table = configuration['std_maping_table']
    plant_coord_lat = configuration['plant_coord_lat']
    plant_coord_long = configuration['plant_coord_long']

    log.info('Plant coord:' + str(plant_coord_lat) + ', ' + str(plant_coord_long))
    data = get_surface_temperature(plant_coord_lat, plant_coord_long)  # ambient temperature
    data_high = get_higher_temp_ambi_factor(data, high_temp_max, high_temp_mean, std_maping_table)
    print(data_high.columns)
    print(type(data_high.index))
    print(df.index)
    data_low = get_lower_temp_ambi_factor(data, low_temp_max, low_temp_mean, std_maping_table)
    print('-----------------------',df.columns)
    print(type(data.index))
    print('===============================',data.columns)    
    
    df = pd.merge_asof(df, data.sort_index()['temp'], left_index=True, right_index=True, #tolerance=pd.Timedelta("3h"),
                       direction="nearest")  # Merge Surface Temp to the main DF
    df['temp'] = df['temp'].fillna(0)
    print('======================================================',df.columns)
    
    df = pd.merge_asof(df, data_high.sort_index()['temp_high_fact'], left_index=True, right_index=True, #tolerance=pd.Timedelta("3h"),
                       direction="nearest") 
    df['temp_high_fact'] = df['temp_high_fact'].fillna(0)
    
    df = pd.merge_asof(df, data_low.sort_index()['temp_low_fact'], left_index=True, right_index=True, #tolerance=pd.Timedelta("3h"),
                       direction="nearest")
    df['temp_low_fact'] = df['temp_low_fact'].fillna(0)

    ls_temperature_sensors = list(stats_file[stats_file['temp_correction'] == True]['Description'])
    for t in ls_temperature_sensors:
        df[t+'_actualtemp'] = df[t]
        df[t] = df[t] + df["temp_low_fact"] - df["temp_high_fact"]  # remove Surface temp from temperature sensors
    df.drop(columns=["temp"], inplace=True)
    log.info('Ambient temp adjusted OK on the following sensors: ' + str(ls_temperature_sensors))
    return df


def undo_temp_correction(df, stats_file, configuration, comp, log):
    """
    Undo correction of ambient temperature using information from meteostat library.
    """
    # commenting as we need corrected values to flow in the output sensor value field
    
    #plant_coord_lat = configuration['plant_coord_lat']
    #plant_coord_long = configuration['plant_coord_long']
    #data = get_surface_temperature(plant_coord_lat, plant_coord_long)  # ambient temperature
    #df = pd.merge_asof(df, data.sort_index()["temp"], left_index=True, right_index=True, tolerance=pd.Timedelta("3h"),
    #                   direction="nearest")  # Merge Surface Temp to the main DF
    #df['temp'] = df['temp'].fillna(0)
    #ls_temperature_sensors = list(
    #    stats_file[(stats_file['temp_correction'] == True) & (stats_file['Equipment'] == comp)]['Description'])
    #for t in ls_temperature_sensors:
    #    df[t] = df[t] + df["temp"]  # remove Surface temp from temperature sensors
    #df.drop(columns=["temp"], inplace=True)
    #log.info('Undo Ambient Temp. Correction in Output File OK on the following sensors: ' + str(ls_temperature_sensors))
    return df


# def load_trained_model(config_file, comp):
#     model_loaded = load_model('./output_files/models/model_' + comp + '.h5')
#     # model_loaded.summary()
#
#     scaler_loaded = joblib.load('./output_files/models/std_scaler_' + comp + '.pkl')
#
#     threshold = config_file['train_thresholds'][comp]
#
#     return model_loaded, scaler_loaded, threshold


def plot_anomalies(filtered_df_test, anomalies, selected_sensors):
    fig = go.Figure()

    # Add traces
    for i in selected_sensors:
        fig.add_trace(go.Scatter(x=filtered_df_test.index, y=filtered_df_test[i], name=i))

    for a in filtered_df_test.index[np.where(anomalies)]:
        fig.add_vline(a, line_width=2.8, line_color="red", opacity=0.3)

    # fig.show()
    fig.write_html("2. Shaft Misalignment Anomalies.html", auto_open=True)


def sigmoid(x, L, x0, k, b):
    y = L / (1 + np.exp(-k * (x - x0))) + b
    return (y)


def health_score_calculation(config_file, test_errors, selected_sensors, d, comp):
    train_thresholds = config_file['train_thresholds'][comp]
    train_stds = config_file['train_stds'][comp]
    train_means = config_file['train_means'][comp]

    HS = pd.DataFrame(columns=selected_sensors)

    for i in selected_sensors:
        # Define here the points in X,Y to fit the sigmoid function:
        xdata = [train_stds[i] * 2 + train_means[i], 1.5 * train_thresholds[i], train_thresholds[i] * 10]
        ydata = [2, 5, 9.9]
        p0 = [max(ydata), np.median(xdata), 1, min(ydata)]  # this is an mandatory initial guess
        popt, pcov = curve_fit(sigmoid, xdata, ydata, p0, method='dogbox')
        HS[i] = sigmoid(test_errors[i], *popt)
        HS[i][HS[i] < 0] = 0  # don't allow HS with negative values
        HS[i][HS[i] > 10] = 10  # don't allow HS higher than 10

    # rename the columns
    # HS.columns = [s + '_HS' for s in selected_sensors]

    # round HS with one decimal
    HS = HS.round(1)

    # invert mapping dict
    d_inv = {v: k for k, v in d.items()}

    # apply invert mapping dict to get the original sensor names
    HS.rename(columns=d_inv, inplace=True)
    return HS


def hs_interpolation_logic_H(sensor_value, mean, H1_LIM, H2_LIM, p=1.3):
    if sensor_value <= mean:
        HS = 0.5
    elif sensor_value <= H1_LIM:
        x = [mean, H1_LIM]
        y = [0.5, 5]
        y_interp = scipy.interpolate.interp1d(x, y)
        HS = np.round(y_interp(sensor_value), 1)
    elif sensor_value <= H2_LIM:
        x = [H1_LIM, H2_LIM]
        y = [5, 7]
        y_interp = scipy.interpolate.interp1d(x, y)
        HS = np.round(y_interp(sensor_value), 1)
    elif sensor_value <= H2_LIM * p:
        x = [H2_LIM, H2_LIM * p]
        y = [7, 10]
        y_interp = scipy.interpolate.interp1d(x, y)
        HS = np.round(y_interp(sensor_value), 1)
    else:
        HS = 10
    return HS


def hs_interpolation_logic_H_and_L(sensor_value, mean, H1_LIM, H2_LIM, L1_LIM, L2_LIM, p=1.3):
    if sensor_value <= L2_LIM / p:
        HS = 10
    elif sensor_value <= L2_LIM:
        x = [L2_LIM / p, L2_LIM]
        y = [10, 7]
        y_interp = scipy.interpolate.interp1d(x, y)
        HS = np.round(y_interp(sensor_value), 1)
    elif sensor_value <= L1_LIM:
        x = [L2_LIM, L1_LIM]
        y = [7, 5]
        y_interp = scipy.interpolate.interp1d(x, y)
        HS = np.round(y_interp(sensor_value), 1)
    elif sensor_value <= mean:
        x = [L1_LIM, mean]
        y = [5, 0.5]
        y_interp = scipy.interpolate.interp1d(x, y)
        HS = np.round(y_interp(sensor_value), 1)
    elif sensor_value <= H1_LIM:
        x = [mean, H1_LIM]
        y = [0.5, 5]
        y_interp = scipy.interpolate.interp1d(x, y)
        HS = np.round(y_interp(sensor_value), 1)
    elif sensor_value <= H2_LIM:
        x = [H1_LIM, H2_LIM]
        y = [5, 7]
        y_interp = scipy.interpolate.interp1d(x, y)
        HS = np.round(y_interp(sensor_value), 1)
    elif sensor_value <= H2_LIM * p:
        x = [H2_LIM, H2_LIM * p]
        y = [7, 10]
        y_interp = scipy.interpolate.interp1d(x, y)
        HS = np.round(y_interp(sensor_value), 1)
    else:
        HS = 10
    return HS

def create_output_csv(filtered_df_test, d_inv, HS, comp, stats_file, configuration, log):
    filtered_df_test = undo_temp_correction(filtered_df_test, stats_file, configuration, comp, log)
    df = filtered_df_test.copy().rename(columns=d_inv)
    df.index.names = ['Start Date']

    df.drop(['temp_high_fact', 'temp_low_fact'], axis=1, inplace=True)
    fun = lambda col: col[:-11] 

    df1 = df[["Start Date"]+list(df.columns[df.columns.str.contains('_actualtemp')])]
    df2 = df[list(df.columns[~df.columns.str.contains('_actualtemp') ])]

    df1.rename(columns={ col: fun(col) for col in df1.columns if col!='Start Date'}, inplace=True)

    df1 = pd.melt(df1.reset_index(drop=True), id_vars='Start Date', value_vars=df1.columns)
    df1.reset_index(drop=True, inplace=True)
    df1.rename(columns={'value':'actual'}, inplace=True)

    df2 = pd.melt(df2.reset_index(drop=True), id_vars='Start Date', value_vars=df2.columns)
    df2.reset_index(drop=True, inplace=True)

    hourly_value = pd.merge(df1, df2,  how='left', left_on=['Start Date','variable'], right_on = ['Start Date','variable'])
    hourly_value = hourly_value.rename(
        columns={"Start Date": "timestamp", "variable": "signal", "value": "hourly_value"})

    # remove duplicated_sensors from hourly_value
    duplicated_sensors = []  # HARDCODED
    for dup in duplicated_sensors:
        hourly_value = hourly_value[hourly_value['signal'] != dup]
    hourly_value.signal.unique()

    HS.index = filtered_df_test.index
    HS.index.names = ['Start Date']
    output_test = HS

    # Create output table
    output_test = pd.melt(output_test.reset_index(), id_vars='Start Date', value_vars=output_test.columns)
    output_test = output_test.sort_values(by=['Start Date', 'variable']).reset_index(drop=True)
    output_test = output_test.rename(columns={"Start Date": "timestamp", "variable": "signal", "value": "health_score"})
    output_test['forecasted_health_score'] = np.NaN
    output_test['severity_status'] = output_test['forecasted_health_score'].apply(severity_status)
    output_test['hourly_std'] = 0  # hardcoded
    output_test = output_test.merge(hourly_value, on=['timestamp', 'signal'])
    output_test['plant_code'] = [x.split('_')[0] for x in output_test['signal']]
    output_test['component'] = comp
    output_test['equipment_code'] = [x.split('_')[1] for x in output_test['signal']]

    # NEW VERSION 29-07-22: APPLY INTERPOLATION FOR ALL
    for s in list(output_test.signal.unique()):
        H1_LIM = float(stats_file[stats_file['index'] == s]['H1_LIM'])
        H2_LIM = float(stats_file[stats_file['index'] == s]['H2_LIM'])
        mean = float(stats_file[stats_file['index'] == s]['mean'].iloc[0])
        wrong_df = output_test.loc[(output_test['signal'] == s)]['hourly_value']
        if stats_file[stats_file['index'] == s]['Lifting_Pressure'].iloc[0]:
            # if Lifting_Pressure==TRUE, USE hs_interpolation_logic_H_and_L
            L1_LIM = float(stats_file[stats_file['index'] == s]['L1_LIM'])
            L2_LIM = float(stats_file[stats_file['index'] == s]['L2_LIM'])
            h = pd.Series([hs_interpolation_logic_H_and_L(x, mean, H1_LIM, H2_LIM, L1_LIM, L2_LIM) for x in wrong_df])
        else:
            # if Lifting_Pressure==FALSE, USE hs_interpolation_logic_H
            h = pd.Series([hs_interpolation_logic_H(x, mean, H1_LIM, H2_LIM) for x in wrong_df])
        h.index = wrong_df.index
        output_test.loc[(output_test['signal'] == s), 'severity_status'] = ''
        output_test.loc[(output_test['signal'] == s), 'health_score'] = h
    return output_test

def create_output_csv_old(filtered_df_test, d_inv, HS, comp, stats_file, configuration, log):
    filtered_df_test = undo_temp_correction(filtered_df_test, stats_file, configuration, comp, log)
    hourly_value = filtered_df_test.copy().rename(columns=d_inv)
    hourly_value.index.names = ['Start Date']
    hourly_value = pd.melt(hourly_value.reset_index(), id_vars='Start Date', value_vars=hourly_value.columns)
    hourly_value = hourly_value.sort_values(by=['Start Date', 'variable']).reset_index(drop=True)
    hourly_value = hourly_value.rename(
        columns={"Start Date": "timestamp", "variable": "signal", "value": "hourly_value"})

    # remove duplicated_sensors from hourly_value
    duplicated_sensors = []  # HARDCODED
    for dup in duplicated_sensors:
        hourly_value = hourly_value[hourly_value['signal'] != dup]
    hourly_value.signal.unique()

    HS.index = filtered_df_test.index
    HS.index.names = ['Start Date']
    output_test = HS

    # Create output table
    output_test = pd.melt(output_test.reset_index(), id_vars='Start Date', value_vars=output_test.columns)
    output_test = output_test.sort_values(by=['Start Date', 'variable']).reset_index(drop=True)
    output_test = output_test.rename(columns={"Start Date": "timestamp", "variable": "signal", "value": "health_score"})
    output_test['forecasted_health_score'] = np.NaN
    output_test['severity_status'] = output_test['forecasted_health_score'].apply(severity_status)
    output_test['hourly_std'] = 0  # hardcoded
    output_test = output_test.merge(hourly_value, on=['timestamp', 'signal'])
    output_test['plant_code'] = [x.split('_')[0] for x in output_test['signal']]
    output_test['component'] = comp
    output_test['equipment_code'] = [x.split('_')[1] for x in output_test['signal']]

    # Check if HS is too high USING AUTOENCODER REMOVING FALSE POSITIVES
    # REMOVES VALUES ONLY OVER H1_LIM or UNDER L1_LIM BASED ON Lifting_Pressure (INTERPOLATION)
    # for s in list(output_test.signal.unique()):
    #     H1_LIM = float(stats_file[stats_file['index'] == s]['H1_LIM'])
    #     H2_LIM = float(stats_file[stats_file['index'] == s]['H2_LIM'])
    #     mean = float(stats_file[stats_file['index'] == s]['mean'].iloc[0])
    #     if stats_file[stats_file['index'] == s]['Lifting_Pressure'].iloc[0]:
    #         # if Lifting_Pressure==TRUE, USE hs_interpolation_logic_H_and_L
    #         L1_LIM = float(stats_file[stats_file['index'] == s]['L1_LIM'])
    #         L2_LIM = float(stats_file[stats_file['index'] == s]['L2_LIM'])
    #         wrong_df = output_test.loc[(output_test['signal'] == s) &
    #                                    (output_test['health_score'] >= 5) &
    #                                    (output_test['hourly_value'] < H1_LIM) &
    #                                    (output_test['hourly_value'] > L1_LIM)]['hourly_value']
    #         h = pd.Series([hs_interpolation_logic_H_and_L(x, mean, H1_LIM, H2_LIM, L1_LIM, L2_LIM) for x in wrong_df])
    #     else:
    #         # if Lifting_Pressure==FALSE, USE hs_interpolation_logic_H
    #         wrong_df = output_test.loc[(output_test['signal'] == s) & (output_test['health_score'] >= 5) &
    #                                    (output_test['hourly_value'] < H1_LIM)]['hourly_value']
    #         h = pd.Series([hs_interpolation_logic_H(x, mean, H1_LIM, H2_LIM) for x in wrong_df])
    #     h.index = wrong_df.index
    #     output_test.loc[(output_test['signal'] == s) & (output_test['health_score'] >= 5) &
    #                     (output_test['hourly_value'] < H1_LIM), 'severity_status'] = 'Running Normal'
    #     output_test.loc[(output_test['signal'] == s) & (output_test['health_score'] >= 5) &
    #                     (output_test['hourly_value'] < H1_LIM), 'health_score'] = h
    # return output_test

    # NEW VERSION 29-07-22: APPLY INTERPOLATION FOR ALL
    for s in list(output_test.signal.unique()):
        H1_LIM = float(stats_file[stats_file['index'] == s]['H1_LIM'])
        H2_LIM = float(stats_file[stats_file['index'] == s]['H2_LIM'])
        mean = float(stats_file[stats_file['index'] == s]['mean'].iloc[0])
        wrong_df = output_test.loc[(output_test['signal'] == s)]['hourly_value']
        if stats_file[stats_file['index'] == s]['Lifting_Pressure'].iloc[0]:
            # if Lifting_Pressure==TRUE, USE hs_interpolation_logic_H_and_L
            L1_LIM = float(stats_file[stats_file['index'] == s]['L1_LIM'])
            L2_LIM = float(stats_file[stats_file['index'] == s]['L2_LIM'])
            h = pd.Series([hs_interpolation_logic_H_and_L(x, mean, H1_LIM, H2_LIM, L1_LIM, L2_LIM) for x in wrong_df])
        else:
            # if Lifting_Pressure==FALSE, USE hs_interpolation_logic_H
            h = pd.Series([hs_interpolation_logic_H(x, mean, H1_LIM, H2_LIM) for x in wrong_df])
        h.index = wrong_df.index
        output_test.loc[(output_test['signal'] == s), 'severity_status'] = ''
        output_test.loc[(output_test['signal'] == s), 'health_score'] = h
    return output_test


def hourly_to_daily(all_outputs):
    sensors = list(all_outputs['signal'].unique())
    daily_df_created = False
    for s in sensors:
        all_outputs['timestamp'] = pd.to_datetime(all_outputs['timestamp'])
        idxmax_per_day = pd.Series(all_outputs[all_outputs['signal'] == s].set_index('timestamp').groupby(
            ['signal', pd.Grouper(freq='D')]).health_score.agg(['max', 'idxmax'])['idxmax'])
        daily_df = pd.merge(all_outputs[all_outputs['signal'] == s], idxmax_per_day, left_on='timestamp',
                            right_on='idxmax', how='inner').set_index('timestamp').resample('1D').max()
        daily_df['signal'].fillna(method='ffill', inplace=True)
        daily_df['component'].fillna(method='ffill', inplace=True)
        daily_df['equipment_code'].fillna(method='ffill', inplace=True)
        daily_df['plant_code'].fillna(method='ffill', inplace=True)
        del daily_df['idxmax']
        if not daily_df_created:
            all_daily_df = daily_df.copy()
            daily_df_created = True
        else:
            all_daily_df = pd.concat([all_daily_df, daily_df])
    c = ['timestamp', 'signal', 'health_score', 'forecasted_health_score', 'severity_status', 'hourly_std',
         'hourly_value', 'plant_code', 'component', 'equipment_code', 'actual_temp']
    all_daily_df['timestamp'] = all_daily_df.index
    all_daily_df.reset_index(inplace=True, drop=True)
    all_daily_df = all_daily_df[c]
    all_daily_df.sort_values(by=['timestamp', 'component', 'signal'], inplace=True)

    return all_daily_df


def loop_on_components_output_generation(stats_file, filtered_df, config_file, components, d, configuration, log):
    flag = 0
    for comp in components:
        log.info('*** Selected machine part: ' + comp)
        # Filter selected sensors
        selected_sensors = list(stats_file[stats_file['Equipment'] == comp]['index'])
        selected_sensors = list(pd.Series(selected_sensors).map(d))

        log.info('List of sensors: ' + str(selected_sensors))
        missing_sensors = list(set(selected_sensors) - set(filtered_df.columns))
        log.info('List of missing sensors in the dataset: ' + str(missing_sensors))

        # filtered_df_selected_sensors = filtered_df[list(set(selected_sensors) & set(filtered_df.columns))].copy()
        filtered_df_selected_sensors = filtered_df[selected_sensors].copy()
        # plot_corr(filtered_df_selected_sensors)    # Correlation for selected_sensors

        # If there are missing sensors, input the mean value between the min and max thresholds in the stats_file
        if len(missing_sensors) != 0:
            for m in missing_sensors:
                mean_val = float((stats_file[stats_file['Description'] == m]['H1_LIM'] +
                                  stats_file[stats_file['Description'] == m]['L1_LIM']) / 2)
                filtered_df_selected_sensors[m] = mean_val
                log.warning('Missing sensor ' + m + ' filled with value: ' + str(mean_val))

        model_loaded = load_model(os.path.join(path_models, 'model_' + remove_weird_symbols(comp) + '.h5'))

        # print('\n- scaler_loaded:')
        # print(os.path.join(path_models, 'std_scaler_' + comp + '.pkl'))
        scaler_loaded = joblib.load(os.path.join(path_models, 'std_scaler_' + remove_weird_symbols(comp) + '.pkl'))

        threshold = config_file['train_thresholds'][comp]

        # duplicate sensor to make_input_num_divisible
        added_feature = False
        if filtered_df_selected_sensors.shape[1] > 5:
            filtered_df_selected_sensors, added_feature = make_input_num_divisible(filtered_df_selected_sensors)
        # print('\n- Added feature: ' + str(added_feature))

        anomalies, x_test, x_test_pred, test_mae_loss = test_model_autoencoder_conv1d(filtered_df_selected_sensors,
                                                                                      threshold['General'],
                                                                                      scaler_loaded,
                                                                                      model_loaded,
                                                                                      selected_sensors,
                                                                                      loss_function_general,
                                                                                      {})
        test_errors = x_test - x_test_pred
        # test_errors = abs(x_test_pred - x_test) # uncomment to consider negative errors too
        test_errors = pd.DataFrame(test_errors.reshape(test_errors.shape[0], test_errors.shape[1]),
                                   columns=filtered_df_selected_sensors.columns)
        test_errors[test_errors < 0] = 0
        HS = health_score_calculation(config_file, test_errors, selected_sensors, d, comp)
        log.info('HS generated OK')

        d_inv = {v: k for k, v in d.items()}  # invert mapping dict
        output_test = create_output_csv(filtered_df_selected_sensors, d_inv, HS, comp, stats_file, configuration, log)

        # uncomment to save individual component health score CSV
        # output_test.to_csv('./output_files/output_' + comp + '.csv')

        if flag == 0:
            all_outputs = output_test.copy()
            flag = 1
        else:
            all_outputs = pd.concat([all_outputs, output_test])
    return all_outputs


# Autoencoder functions from this point
def scale_data(filtered_df_train, sensors):
    """
    Scale data before training.
    """
    x_train = filtered_df_train[sensors]

    # Fill/remove null values
    x_train = x_train.fillna(method='ffill').dropna()

    # Normalize dataset to train faster
    scaler = StandardScaler()
    scaler.fit(x_train)
    x_train = scaler.transform(x_train)

    # Reshape x_train:
    x_train = x_train.reshape((x_train.shape[0], x_train.shape[1], 1))
    x_train.shape

    return x_train, scaler


def divisors(n):
    result = set()
    for i in range(1, int(n ** 0.5) + 1):
        if n % i == 0:
            result.add(i)
            result.add(n // i)
    return list(sorted(result))


def make_input_num_divisible(df):
    added_feat = False
    if len(divisors(df.shape[1])) < 3:
        added_feat = True
        feat = df.columns[-1]
        df[feat + '_copy'] = df[feat]
    return df, added_feat


def loss_function(a_target, a_pred):
    """
    Loss Function for the Autoencoder Model.
    """
    loss_per_sample = []
    diffs = a_target - a_pred
    for sample in diffs:
        sample = sample[sample > 0]
        #         if len(sample)==0
        #             sample=[0]
        loss_per_sample.append(sample.sum())  # /len(a_target))
    return np.array(loss_per_sample)


def train_model_autoencoder_conv1d(x_train, model):
    '''
    Train Autoencoder Model.
    '''
    history = model.fit(
        x_train,
        x_train,
        epochs=300,
        batch_size=64,
        validation_split=0.1,
        callbacks=[
            keras.callbacks.EarlyStopping(monitor="val_loss", patience=20, mode="min", restore_best_weights=True)]
        #         callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=20, mode="min")]
    )

    # Uncomment to plot training losses:
    # plt.plot(history.history["loss"], label="Training Loss")
    # plt.plot(history.history["val_loss"], label="Validation Loss")
    # plt.legend()
    # plt.show()

    x_train_pred = model.predict(x_train)  # Get train MAE loss.

    return x_train_pred, history


def extract_threshold(x_train, x_train_pred, loss_fun, quantile, param_dict, selected_sensors, log):
    """
    Extract threshold from train_mae_loss
    """
    # Apply loss function
    # train_mae_loss = np.mean(x_train - x_train_pred, axis=1)
    train_mae_loss = loss_fun(x_train, x_train_pred, param_dict, selected_sensors)

    # Uncomment to plot error histogram
    # plt.hist(train_mae_loss, bins=50, density=True)
    # pd.DataFrame(train_mae_loss)[0].plot()  # (kind='kde')
    # plt.xlabel("Train MAE loss")
    # plt.ylabel("No of samples")
    # plt.show()

    # Get reconstruction loss threshold.
    threshold = np.nanquantile(train_mae_loss, [quantile])
    log.info("Reconstruction error threshold: " + str(threshold))

    return train_mae_loss, threshold


def test_model_autoencoder_conv1d(filtered_df_test, threshold, scaler_loaded, model, sensors, loss_fun, param_dict):
    """
    Test Autoencoder Model.
    """
    # print(filtered_df_test.columns)
    sensors = np.array(filtered_df_test.columns)
    x_test = filtered_df_test[sensors]

    # Fill/remove null values
    x_test = x_test.fillna(method='ffill').dropna()

    # print('\n- x_test before scaling: ')
    # print(pd.DataFrame(x_test))

    # Apply scaler
    x_test = scaler_loaded.transform(x_test)
    # print('\n- x_test after scaling: ')
    # print(pd.DataFrame(x_test))

    # Reshape
    x_test = x_test.reshape((x_test.shape[0], x_test.shape[1], 1))

    # Get test MAE loss.
    x_test_pred = model.predict(x_test)
    # test_mae_loss = np.mean(np.abs(x_test_pred - x_test), axis=1)
    test_mae_loss = loss_fun(x_test, x_test_pred, param_dict, sensors)
    test_mae_loss = test_mae_loss.reshape((-1))

    # Uncomment to plot anomalies and MAE distriburion
    # plt.hist(test_mae_loss, bins=50)
    # plt.xlabel("test MAE loss")
    # plt.ylabel("No of samples")
    # plt.show()
    # print('\n- test_model_autoencoder_conv1d---test_mae_loss:')
    # print(test_mae_loss)
    # print('\n- test_model_autoencoder_conv1d---threshold:')
    # print(threshold)
    # Detect all the samples which are anomalies.
    anomalies = test_mae_loss > threshold
    # print("\n- Number of anomaly samples: ", np.sum(anomalies))
    # print("\n- Indices of anomaly samples: ", np.where(anomalies))

    return anomalies, x_test, x_test_pred, test_mae_loss


# def plot_ae_prediction(a_target, a_pred, ls_input_names, idx):
#     plt.plot(a_target[idx])
#     plt.plot(a_pred[idx])
#     plt.xticks(range(0, len(ls_input_names)), ls_input_names, rotation=70)
#     plt.legend(["real", "predicted"])
#     plt.show()
#     return


# def plot_series_with_anomalies(ls_sensor_names, failure_type, filtered_df_test, bool_anomalies, filename):
#     pd.options.plotting.backend = "plotly"
#     import plotly.graph_objects as go
#
#     fig = go.Figure()
#     # Add traces
#     for i in ls_sensor_names:
#         fig.add_trace(go.Scatter(x=filtered_df_test.index, y=filtered_df_test[i], name=i))
#     for a in filtered_df_test.index[np.where(bool_anomalies)]:
#         fig.add_vline(a, line_width=2.8, line_color="red", opacity=0.3)
#     fig.update_layout(title=failure_type + filename)
#     fig.write_html("plots/" + failure_type + filename, auto_open=True)
#     return


def severity_status(hs):
    if 0 <= hs < 5:
        r = 'Running Normal'
    elif 5 <= hs < 7:
        r = 'Maintenance Required'
    elif 7 <= hs < 9:
        r = 'Critical State'
    elif 9 <= hs <= 10:
        r = 'Immediate Attention Required'
    else:
        r = 'Health Score Out of Limits'
    return r


def rules_forecasting(signal, values_ahead, window, short_window, last_forecast=np.nan):
    all_avg = np.mean(signal)
    start_avg = np.mean(signal[:short_window])
    end_avg = np.mean(signal[short_window:])
    short_avg = np.mean(signal[len(signal) - 2 * short_window:len(signal) - short_window])
    std_all = np.std(signal)

    gap_short = signal[-1] - short_avg
    gap_long = end_avg - start_avg
    gap_diff = gap_short - gap_long

    regress_long = linregress([0, window - short_window], [start_avg, end_avg])
    regress_short = linregress([0, short_window], [short_avg, end_avg])

    slope_long = regress_long[0]
    slope_short = regress_short[0]
    slope_diff = slope_short - slope_long

    if (std_all < 1) & (abs(gap_short) < 1.5):
        #     if (std_all<1) & (gap_short>1): # gap positiu, baixa
        forecast = all_avg
    elif (gap_short > 4) | (gap_short < -0.25):  # & (gap_short<2)
        #         if last_forecast is not None:
        #             forecast = last_forecast
        #         else:
        forecast = signal[-1]
    else:
        forecast = slope_long * values_ahead + end_avg
    forecast = max(0, min(10, forecast))

    return forecast, gap_short, gap_long, gap_diff, slope_short, slope_long, slope_diff, std_all, all_avg


def plot_hs_forecast(filtered_df_test, values_ahead, window, short_window):
    data = filtered_df_test.resample('1H').mean().interpolate()
    values_ahead = values_ahead
    window = window
    nbr_cases = data.shape[0]
    forecast = [np.nan for i in range(values_ahead + window)]
    forecast = [np.nan for i in range(window)]
    gap_s = [np.nan for i in range(window)]
    gap_l = [np.nan for i in range(window)]
    gap_d = [np.nan for i in range(window)]
    slope_s = [np.nan for i in range(window)]
    slope_l = [np.nan for i in range(window)]
    slope_d = [np.nan for i in range(window)]
    stdev = [np.nan for i in range(window)]
    rolling_avg = [np.nan for i in range(window)]

    for i in range(window, nbr_cases):
        if data.iloc[i - window:i, 0].isna().sum() / window < .5:
            result, gap_short, gap_long, gap_diff, slope_short, slope_long, slope_diff, std_all, all_avg = \
                rules_forecasting(data.iloc[i - window:i, 0], values_ahead=values_ahead, window=window,
                                  short_window=short_window, last_forecast=forecast[-1])
        else:
            result = gap_short = gap_long = gap_diff = slope_short = slope_long = slope_diff = std_all = all_avg = np.nan
        forecast.append(result)
        gap_s.append(gap_short)
        gap_l.append(gap_long)
        gap_d.append(gap_diff)
        slope_s.append(slope_short)
        slope_l.append(slope_long)
        slope_d.append(slope_diff)
        stdev.append(std_all)
        rolling_avg.append(all_avg)

    # shifted_time = data.index + datetime.timedelta(hours=values_ahead)

    df_transfo = data.copy()
    df_transfo['gap_s'] = gap_s
    df_transfo['gap_l'] = gap_l
    df_transfo['slope_s'] = slope_s
    df_transfo['slope_l'] = slope_l
    df_transfo['slope_d'] = slope_d
    df_transfo['stdev'] = stdev
    df_transfo['rolling_avg'] = rolling_avg

    # fig = make_subplots(rows=2, cols=1,
    #                     shared_xaxes=True,
    #                     vertical_spacing=0.02)
    # fig.add_trace(go.Scatter(x=data.index, y=data['health_score'],
    #                          name='original signal', line=dict(color='#424143')), row=1, col=1)
    # fig.add_trace(go.Scatter(x=data.index, y=rolling_avg,
    #                          name='rolling_avg', line=dict(color='red')), row=1, col=1)
    # fig.add_trace(go.Scatter(x=data.index, y=forecast,
    #                          name='forecast', line=dict(color='goldenrod')), row=1, col=1)
    # fig.add_trace(go.Scatter(x=data.index, y=gap_s,
    #                          name='gap_s', line=dict(color='green')), row=1, col=1)
    # fig.add_trace(go.Scatter(x=data.index, y=gap_l,
    #                          name='gap_l', line=dict(color='purple')), row=1, col=1)
    # fig.add_trace(go.Scatter(x=data.index, y=gap_d,
    #                          name='gap_d', line=dict(color='lime')), row=1, col=1)
    # fig.add_trace(go.Scatter(x=data.index, y=slope_s,
    #                          name='slope_short', line=dict(color='blue')), row=2, col=1)
    # fig.add_trace(go.Scatter(x=data.index, y=slope_l,
    #                          name='slope_long', line=dict(color='red')), row=2, col=1)
    # fig.add_trace(go.Scatter(x=data.index, y=slope_d,
    #                          name='slope_diff', line=dict(color='orange')), row=2, col=1)
    # fig.add_trace(go.Scatter(x=data.index, y=stdev,
    #                          name='stdev', line=dict(color='royalblue')), row=1, col=1)
    # fig.update_layout(showlegend=True, title_text="Forecasting model results", width=980, height=980)

    return forecast  # , fig


def get_higher_temp_ambi_factor(input_data, max, mean, std_maping_table):
    input_data = input_data.copy()
    # define the std 
    std = (max - mean)/3
    std_mapping = std_maping_table
    std_mapping= sorted(std_mapping.values())
    col = 'temp'

    # Iterate over the std factor and assign factor according to distance from mean
    for idx, value in enumerate(std_mapping, start=1):
        if idx == 1:
            first_threshold_lower = mean - value*std
            first_threshold_upper = mean + value*std
            input_data.loc[((input_data['temp'] >= first_threshold_lower) & (input_data['temp'] <= first_threshold_upper)),col+"_high_fact"] = np.random.uniform(0.5,2)

        threshold_upper = mean + value * std
        threshold_lower = mean - value * std
        
        input_data.loc[input_data['temp'] < threshold_lower, col + "_high_fact"] = np.random.uniform(1,4)
        input_data.loc[input_data['temp'] > threshold_upper, col + "_high_fact"] = np.random.uniform((idx-1)/2,idx/2)
        
        # No effect on low temp
        input_data.loc[input_data['temp'] < mean , col+"_high_fact"] = 0

    return input_data

def get_lower_temp_ambi_factor(input_data, max, mean, std_maping_table):
    input_data = input_data.copy()
    std = (max - mean)/3
    std_mapping = std_maping_table
    std_mapping= sorted(std_mapping.values())

    col = 'temp'
    # Iterate over the std factor and assign factor according to distance from mean
    for idx, value in enumerate(std_mapping, start=1):
        if idx == 1:
            first_threshold_lower = mean - value*std
            first_threshold_upper = mean + value*std
            input_data.loc[((input_data['temp'] >= first_threshold_lower) & (input_data['temp'] <= first_threshold_upper)),col+"_low_fact"] = 0

        threshold_upper = mean + value * std
        threshold_lower = mean - value * std
        
        input_data.loc[input_data['temp'] < threshold_lower, col + "_low_fact"] = 0
        input_data.loc[input_data['temp'] > threshold_upper, col + "_low_fact"] = np.random.uniform((idx-1)/2,idx/2)

    # Get the rev factor for low ambient temp
    input_data[col+"_low_fact"] = (np.max(input_data[col+"_low_fact"]) - input_data[col+"_low_fact"])/2
    
    # No effect for high temp
    input_data.loc[input_data['temp'] >= max , col+"_low_fact"] = 0
    return input_data

# def add_original_temp_to_output(df_orig, all_outputs,stats_file, d_inv):
#     # format to have same structure as processed data
#     temperature_sensors = list(stats_file[stats_file['temp_correction'] == True]['Description'])
    
#     # Keep only temp sensors that are 'true' for ambient temp correction
#     temp1 = df_orig[temperature_sensors]
#     print(temp1.columns)

#     # Apply inverse dictionary
#     temp1.rename(columns=d_inv, inplace=True)

#     # temp1.index.names = ['Start Date']
#     temp1 = pd.melt(temp1.reset_index(), id_vars='Start Date', value_vars=temp1.columns)
#     print('||||||||||||||||||||||||',temp1.columns)

#     # temp1.set_index("Start Date",inplace = True)
#     print(type(temp1.index))
#     # temp1 = temp1.rename(
#     #     columns={"Start Date": "timestamp", "variable": "signal", "value": "actual_temp"})
#     print(all_outputs.columns)
#     print(temp1.columns)
#     # merge data
#     # temp2 = all_outputs.merge(temp1, on = ['timestamp', 'signal'], how='left')
#     # temp2 = pd.merge_asof(all_outputs, temp1, left_by=['timestamp','signal'])
#     # temp2['temp'] = temp2['temp'].fillna(0)
#     temp2 = pd.merge_asof(all_outputs, temp1.sort_index()['value'], left_index=True, right_index=True) #tolerance=pd.Timedelta("3h"),
#                     #    direction="nearest")
#     print('-----------------------',temp2.columns)                
#     # temp2 = pd.merge_asof(all_outputs, temp1.sort_index()['signal'], left_index=True, right_index=True, #tolerance=pd.Timedelta("3h"),
#     #                    direction="nearest")
#     return temp2


    # temp2 = pd.merge_asof(all_outputs, temp1.sort_index()['timestamp','signal'], left_index=True, right_index=True, #tolerance=pd.Timedelta("3h"),
                    #    direction="nearest")
def create_output_csv(filtered_df_test, d_inv, HS, comp, stats_file, configuration, log):
    filtered_df_test = undo_temp_correction(filtered_df_test, stats_file, configuration, comp, log)
    hourly_value = filtered_df_test.copy().rename(columns=d_inv)
    hourly_value.index.names = ['Start Date']
    hourly_value = pd.melt(hourly_value.reset_index(), id_vars='Start Date', value_vars=hourly_value.columns)
    hourly_value = hourly_value.sort_values(by=['Start Date', 'variable']).reset_index(drop=True)
    hourly_value = hourly_value.rename(
        columns={"Start Date": "timestamp", "variable": "signal", "value": "hourly_value"})

    # remove duplicated_sensors from hourly_value
    duplicated_sensors = []  # HARDCODED
    for dup in duplicated_sensors:
        hourly_value = hourly_value[hourly_value['signal'] != dup]
    hourly_value.signal.unique()

    HS.index = filtered_df_test.index
    HS.index.names = ['Start Date']
    output_test = HS

    # Create output table
    output_test = pd.melt(output_test.reset_index(), id_vars='Start Date', value_vars=output_test.columns)
    output_test = output_test.sort_values(by=['Start Date', 'variable']).reset_index(drop=True)
    output_test = output_test.rename(columns={"Start Date": "timestamp", "variable": "signal", "value": "health_score"})
    output_test['forecasted_health_score'] = np.NaN
    output_test['severity_status'] = output_test['forecasted_health_score'].apply(severity_status)
    output_test['hourly_std'] = 0  # hardcoded
    output_test = output_test.merge(hourly_value, on=['timestamp', 'signal'])
    output_test['plant_code'] = [x.split('_')[0] for x in output_test['signal']]
    output_test['component'] = comp
    output_test['equipment_code'] = [x.split('_')[1] for x in output_test['signal']]

    # Check if HS is too high USING AUTOENCODER REMOVING FALSE POSITIVES
    # REMOVES VALUES ONLY OVER H1_LIM or UNDER L1_LIM BASED ON Lifting_Pressure (INTERPOLATION)
    # for s in list(output_test.signal.unique()):
    #     H1_LIM = float(stats_file[stats_file['index'] == s]['H1_LIM'])
    #     H2_LIM = float(stats_file[stats_file['index'] == s]['H2_LIM'])
    #     mean = float(stats_file[stats_file['index'] == s]['mean'].iloc[0])
    #     if stats_file[stats_file['index'] == s]['Lifting_Pressure'].iloc[0]:
    #         # if Lifting_Pressure==TRUE, USE hs_interpolation_logic_H_and_L
    #         L1_LIM = float(stats_file[stats_file['index'] == s]['L1_LIM'])
    #         L2_LIM = float(stats_file[stats_file['index'] == s]['L2_LIM'])
    #         wrong_df = output_test.loc[(output_test['signal'] == s) &
    #                                    (output_test['health_score'] >= 5) &
    #                                    (output_test['hourly_value'] < H1_LIM) &
    #                                    (output_test['hourly_value'] > L1_LIM)]['hourly_value']
    #         h = pd.Series([hs_interpolation_logic_H_and_L(x, mean, H1_LIM, H2_LIM, L1_LIM, L2_LIM) for x in wrong_df])
    #     else:
    #         # if Lifting_Pressure==FALSE, USE hs_interpolation_logic_H
    #         wrong_df = output_test.loc[(output_test['signal'] == s) & (output_test['health_score'] >= 5) &
    #                                    (output_test['hourly_value'] < H1_LIM)]['hourly_value']
    #         h = pd.Series([hs_interpolation_logic_H(x, mean, H1_LIM, H2_LIM) for x in wrong_df])
    #     h.index = wrong_df.index
    #     output_test.loc[(output_test['signal'] == s) & (output_test['health_score'] >= 5) &
    #                     (output_test['hourly_value'] < H1_LIM), 'severity_status'] = 'Running Normal'
    #     output_test.loc[(output_test['signal'] == s) & (output_test['health_score'] >= 5) &
    #                     (output_test['hourly_value'] < H1_LIM), 'health_score'] = h
    # return output_test

    # NEW VERSION 29-07-22: APPLY INTERPOLATION FOR ALL
    for s in list(output_test.signal.unique()):
        H1_LIM = float(stats_file[stats_file['index'] == s]['H1_LIM'])
        H2_LIM = float(stats_file[stats_file['index'] == s]['H2_LIM'])
        mean = float(stats_file[stats_file['index'] == s]['mean'].iloc[0])
        wrong_df = output_test.loc[(output_test['signal'] == s)]['hourly_value']
        if stats_file[stats_file['index'] == s]['Lifting_Pressure'].iloc[0]:
            # if Lifting_Pressure==TRUE, USE hs_interpolation_logic_H_and_L
            L1_LIM = float(stats_file[stats_file['index'] == s]['L1_LIM'])
            L2_LIM = float(stats_file[stats_file['index'] == s]['L2_LIM'])
            h = pd.Series([hs_interpolation_logic_H_and_L(x, mean, H1_LIM, H2_LIM, L1_LIM, L2_LIM) for x in wrong_df])
        else:
            # if Lifting_Pressure==FALSE, USE hs_interpolation_logic_H
            h = pd.Series([hs_interpolation_logic_H(x, mean, H1_LIM, H2_LIM) for x in wrong_df])
        h.index = wrong_df.index
        output_test.loc[(output_test['signal'] == s), 'severity_status'] = ''
        output_test.loc[(output_test['signal'] == s), 'health_score'] = h
    return output_test